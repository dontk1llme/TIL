# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
# 반드시 재귀함수로 구현해야 합니다.
def dec_to_bin(number):
    # 여기에 코드를 작성하여 함수를 완성합니다.
    '''
    보기에서와 같이 나머지를 기준으로 '0' 혹은 '1'을 붙인다.
    
    재귀 함수로 구성해 계속 호출하며 이진수를 붙여나간다.
    '''
    if number == 0:
        return '0'
    elif number == 1:
        return '1'
    else:
        if number % 2 == 0:
            return  dec_to_bin(number//2) + '0'
        else:
            return  dec_to_bin(number//2) + '1'
    


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
########## 코드 변경 금지 ############
if __name__ == '__main__':
    print(dec_to_bin(10))  # 1010
    print(dec_to_bin(5))   # 101
    print(dec_to_bin(50))  # 110010

<template>
  <div>
    <h3>
        ssafy 여러분을 응원합ㄴ1다
    </h3>
  </div>
</template>

<script>
export default {
    name:'MyChild'
}
</script>

<style>

</style>